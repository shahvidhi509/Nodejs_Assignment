export interface employee {
    name: string,
    position: string,
    office: string,
    salary: number
}
